import { index, route } from "@react-router/dev/routes";

export default [
  index("routes/index.jsx"),
  route("signin", "routes/signin.jsx"),
  route("join", "routes/join.jsx"),
  route("account", "routes/account.jsx"),
  route("logout", "routes/logout.jsx"),
  route("verify", "routes/verify.jsx"),
  route("members.xlsx", "routes/members-xlsx.jsx"),
];
