import { useState } from "react";
import { NavLink } from "react-router";

export function AuthShell({ children, tabs = false, wide = false }) {
  return (
    <div className="wrap">
      <aside className="brand">
        <div className="logo">
          <svg width="38" height="38" viewBox="0 0 40 40" aria-hidden="true">
            <rect width="40" height="40" rx="6" fill="#e8a200" />
            <path
              d="M10 28l10-16 10 16M15 28l5-8 5 8"
              fill="none"
              stroke="#0b2545"
              strokeWidth="3"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          <div>
            <b>The Elevation Center</b>
            <span>University of New Haven</span>
          </div>
        </div>
        <h1>Elevating talent, technology, and innovation.</h1>
        <p className="lead">
          Join a network of manufacturers, educators, and students connected
          through mentorship, introductions, and real-world collaboration.
        </p>
        <ul className="pillars">
          <li>
            <b>Elevate Talent</b>
            <span>Skills and experience to lead</span>
          </li>
          <li>
            <b>Elevate Innovation</b>
            <span>Applied research, real solutions</span>
          </li>
          <li>
            <b>Elevate Partnership</b>
            <span>Industry, academia, government</span>
          </li>
          <li>
            <b>Elevate Impact</b>
            <span>Regional competitiveness</span>
          </li>
        </ul>
        <footer>300 Boston Post Road, West Haven, CT 06516</footer>
      </aside>
      <main className="panel">
        <div className={`box${wide ? " wide" : ""}`}>
          {tabs && (
            <nav className="tabs" aria-label="Account">
              <NavLink to="/signin">Sign in</NavLink>
              <NavLink to="/join">Join</NavLink>
            </nav>
          )}
          {children}
        </div>
      </main>
    </div>
  );
}

export function PasswordField({ id, name, label, autoComplete, error, hint }) {
  return (
    <PasswordInner
      id={id}
      name={name}
      label={label}
      autoComplete={autoComplete}
      error={error}
      hint={hint}
    />
  );
}

function PasswordInner(p) {
  const [show, setShow] = useState(false);
  return (
    <div className={`f${p.error ? " bad" : ""}`}>
      <label className="l" htmlFor={p.id}>
        {p.label}
      </label>
      <div className="pw">
        <input
          id={p.id}
          name={p.name}
          type={show ? "text" : "password"}
          autoComplete={p.autoComplete}
          aria-invalid={!!p.error}
        />
        <button
          type="button"
          onClick={() => setShow((s) => !s)}
          aria-label={show ? "Hide password" : "Show password"}
        >
          {show ? "Hide" : "Show"}
        </button>
      </div>
      {p.hint && !p.error && <div className="hint">{p.hint}</div>}
      {p.error && <div className="msg">{p.error}</div>}
    </div>
  );
}
