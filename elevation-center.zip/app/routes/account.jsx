import { Form, Link, useNavigation } from "react-router";
import { AuthShell } from "../components/auth-shell";
import { newVerifyToken } from "../lib/accounts.server";
import { appOrigin, sendMail } from "../lib/mail.server";
import { getMember } from "../lib/members.server";
import { isStaff, requireAccount } from "../lib/session.server";

export function meta() {
  return [{ title: "My membership | The Elevation Center" }];
}

export async function loader({ request }) {
  const acc = await requireAccount(request);
  const live = await getMember(acc.email); // reflects edits staff make in the Excel
  const rec = { ...acc.record, ...live };
  return {
    rec,
    firstName: acc.firstName,
    staff: isStaff(acc.email),
    joined: new URL(request.url).searchParams.get("joined") === "1",
  };
}

export async function action({ request }) {
  const acc = await requireAccount(request);
  const token = await newVerifyToken(acc.email);
  if (token) {
    await sendMail(
      acc.email,
      "Verify your school email | The Elevation Center",
      `Confirm your school email:\n${appOrigin(request)}/verify?token=${token}`,
    );
  }
  return { resent: !!token };
}

export default function Account({ loaderData, actionData }) {
  const { rec, firstName, staff, joined } = loaderData;
  const busy = useNavigation().state === "submitting";
  const student = rec.tier === "Student";
  const rows = [
    ["Name", rec.name],
    ["Email", rec.email],
    ["Membership", rec.tier],
    ["Type", rec.type],
    ["Dues status", rec.paid],
    ["Joined", rec.joinDate],
    ["Renews", rec.renewalDate],
    ["Welcome call", rec.welcomeCall],
  ];
  if (student)
    rows.splice(5, 0, ["School email verified", rec.schoolEmailVerified]);
  else rows.push(["Ambassador page", rec.listing]);
  rows.push(["Options", rec.options || "None selected"]);
  return (
    <AuthShell>
      <h2 className="title">Hello, {firstName}</h2>
      <p className="sub">Your Elevation Center membership.</p>
      {joined && (
        <div className="okbox" role="status">
          {student
            ? "Your free Student membership is registered. Check your school email for a verification link."
            : "Registration received. We will email you instructions to pay your dues and activate your membership."}
        </div>
      )}
      {actionData?.resent && (
        <div className="okbox" role="status">
          A new verification link was sent.
        </div>
      )}
      <dl className="sum">
        {rows.map(([k, v]) => (
          <div key={k}>
            <dt>{k}</dt>
            <dd>{v}</dd>
          </div>
        ))}
      </dl>
      {!student && rec.paid === "Unpaid" && (
        <div className="note">
          <b>Payment pending.</b> Online payment will open once the University
          approves the payment path. We will email you when it is ready.
        </div>
      )}
      {student && rec.schoolEmailVerified !== "Yes" && (
        <Form method="post" className="note">
          <b>Verify your school email.</b> We sent a link to {rec.email}.{" "}
          <button
            className="lnk"
            type="submit"
            disabled={busy}
            style={{
              background: "none",
              border: 0,
              padding: 0,
              cursor: "pointer",
              font: "inherit",
              fontWeight: 600,
            }}
          >
            Send it again
          </button>
        </Form>
      )}
      {staff && (
        <p>
          <a href="/members.xlsx" download>
            Download the member Excel
          </a>
        </p>
      )}
      <Form method="post" action="/logout">
        <button className="btn s full" type="submit">
          Sign out
        </button>
      </Form>
      <p className="fine">
        <Link to="/signin">Back to sign in</Link>
      </p>
    </AuthShell>
  );
}
