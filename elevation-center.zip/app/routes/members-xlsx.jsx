import { readFile } from "node:fs/promises";
import { MEMBERS_XLSX } from "../lib/config.server";
import { isStaff, requireAccount } from "../lib/session.server";

/** Staff only: downloads the shared member Excel. */
export async function loader({ request }) {
  const acc = await requireAccount(request);
  if (!isStaff(acc.email)) throw new Response("Forbidden", { status: 403 });
  try {
    const file = await readFile(MEMBERS_XLSX);
    return new Response(new Uint8Array(file), {
      headers: {
        "Content-Type":
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": 'attachment; filename="members.xlsx"',
        "Cache-Control": "no-store",
      },
    });
  } catch {
    throw new Response("No members yet", { status: 404 });
  }
}
