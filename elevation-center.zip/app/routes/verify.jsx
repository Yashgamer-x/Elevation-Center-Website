import { Link } from "react-router";
import { AuthShell } from "../components/auth-shell";
import { consumeVerifyToken } from "../lib/accounts.server";
import { setSchoolEmailVerified } from "../lib/members.server";

export function meta() {
  return [{ title: "Verify email | The Elevation Center" }];
}

export async function loader({ request }) {
  const token = new URL(request.url).searchParams.get("token") ?? "";
  const acc = token ? await consumeVerifyToken(token) : null;
  if (acc) await setSchoolEmailVerified(acc.email);
  return { ok: !!acc };
}

export default function Verify({ loaderData }) {
  return (
    <AuthShell>
      {loaderData.ok ? (
        <>
          <h2 className="title">Email verified</h2>
          <p className="sub">
            Thank you. Your school email is confirmed and your Student
            membership is active.
          </p>
          <Link className="btn p full" to="/account">
            Go to my membership
          </Link>
        </>
      ) : (
        <>
          <h2 className="title">Link not valid</h2>
          <p className="sub">
            This verification link is invalid or has already been used. Sign in
            to request a new one.
          </p>
          <Link className="btn p full" to="/signin">
            Sign in
          </Link>
        </>
      )}
    </AuthShell>
  );
}
