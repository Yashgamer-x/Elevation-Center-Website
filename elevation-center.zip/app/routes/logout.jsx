import { redirect } from "react-router";
import { signOut } from "../lib/session.server";

export const loader = () => redirect("/signin");

export const action = ({ request }) => signOut(request);
