import { Form, Link, data, redirect, useNavigation } from "react-router";
import { AuthShell, PasswordField } from "../components/auth-shell";
import { tooManyAttempts, verifyLogin } from "../lib/accounts.server";
import { currentAccount, safeNext, signIn } from "../lib/session.server";
import { EMAIL_RE } from "../lib/validation";

export function meta() {
  return [{ title: "Sign in | The Elevation Center" }];
}

export async function loader({ request }) {
  if (await currentAccount(request)) throw redirect("/account");
  return null;
}

export async function action({ request }) {
  const fd = await request.formData();
  const email = String(fd.get("email") ?? "")
    .trim()
    .toLowerCase();
  const password = String(fd.get("password") ?? "");
  const errors = {};
  if (!EMAIL_RE.test(email)) errors.email = "Enter a valid email address.";
  if (!password) errors.password = "Enter your password.";
  if (errors.email || errors.password)
    return data({ errors, email }, { status: 400 });
  if (tooManyAttempts(email)) {
    errors.form = "Too many attempts. Please wait a few minutes and try again.";
    return data({ errors, email }, { status: 429 });
  }
  const acc = await verifyLogin(email, password);
  if (!acc) {
    errors.form = "Incorrect email or password.";
    return data({ errors, email }, { status: 401 });
  }
  const next = safeNext(new URL(request.url).searchParams.get("next"));
  return signIn(acc.email, fd.get("remember") === "on", next);
}

export default function SignIn({ actionData }) {
  const busy = useNavigation().state === "submitting";
  const errors = actionData?.errors ?? {};
  return (
    <AuthShell tabs>
      <Form method="post" noValidate>
        <h2 className="title">Welcome back</h2>
        <p className="sub">Sign in to manage your membership.</p>
        {errors.form && (
          <div className="alert" role="alert">
            {errors.form}
          </div>
        )}
        <div className={`f${errors.email ? " bad" : ""}`}>
          <label className="l" htmlFor="email">
            Email address
          </label>
          <input
            id="email"
            name="email"
            type="email"
            autoComplete="username"
            defaultValue={actionData?.email ?? ""}
            aria-invalid={!!errors.email}
          />
          {errors.email && <div className="msg">{errors.email}</div>}
        </div>
        <PasswordField
          id="password"
          name="password"
          label="Password"
          autoComplete="current-password"
          error={errors.password}
        />
        <div className="between">
          <label className="chk" style={{ padding: 0 }}>
            <input type="checkbox" name="remember" />
            <span>Keep me signed in</span>
          </label>
        </div>
        <button className="btn p full" type="submit" disabled={busy}>
          {busy ? "Signing in..." : "Sign in"}
        </button>
        <p className="fine">
          Not a member yet? <Link to="/join">Join the Elevation Center</Link>
        </p>
      </Form>
    </AuthShell>
  );
}
