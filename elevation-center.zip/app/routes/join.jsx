import { useEffect, useRef, useState } from "react";
import { Form, Link, data, redirect, useNavigation } from "react-router";
import { AuthShell, PasswordField } from "../components/auth-shell";
import { createAccount, makeToken } from "../lib/accounts.server";
import { PRIVACY_URL, TERMS_URL } from "../lib/config";
import { appOrigin, sendMail } from "../lib/mail.server";
import { appendMember } from "../lib/members.server";
import { currentAccount, signIn } from "../lib/session.server";
import {
  FIELD_STEP,
  MEMBER_TYPES,
  MENTEE_OPTIONS,
  MENTOR_OPTIONS,
  TIERS,
  WELCOME,
  allowedOptions,
  parseJoin,
  validateJoin,
} from "../lib/validation";

export function meta() {
  return [{ title: "Join | The Elevation Center" }];
}

export async function loader({ request }) {
  if (await currentAccount(request)) throw redirect("/account");
  return null;
}

const iso = (d) => d.toISOString().slice(0, 10);

function plusYear(d) {
  const r = new Date(
    Date.UTC(d.getUTCFullYear() + 1, d.getUTCMonth(), d.getUTCDate()),
  );
  if (r.getUTCMonth() !== d.getUTCMonth()) r.setUTCDate(0); // Feb 29 -> Feb 28
  return r;
}

export async function action({ request }) {
  const values = parseJoin(await request.formData());
  const errors = validateJoin(values);
  const echo = { ...values, password: "" };
  if (Object.keys(errors).length)
    return data({ errors, values: echo }, { status: 400 });
  const tier = values.tier;
  const stu = tier === "stu";
  const allowed = allowedOptions(tier, values.wantMentor);
  const options = [
    ...new Set(values.options.filter((o) => allowed.includes(o))),
  ];
  const joined = new Date();
  const record = {
    name: `${values.firstName} ${values.lastName}`,
    email: values.email,
    tier: TIERS[tier].label,
    type: stu ? "Student" : values.type,
    paid: stu ? "Free" : "Unpaid",
    joinDate: iso(joined),
    renewalDate: iso(plusYear(joined)),
    schoolEmailVerified: stu ? "No" : "N/A",
    consent: "Yes",
    listing: stu ? "N/A" : values.listing ? "Yes" : "No",
    options: options.join("; "),
    welcomeCall: options.includes(WELCOME) ? "To schedule" : "Not requested",
    outcome: "",
    owner: "",
    nextStep: "",
  };
  const token = stu ? makeToken() : undefined;
  const account = await createAccount({
    email: values.email,
    firstName: values.firstName,
    verifyToken: token,
    record,
    password: values.password,
  });
  if (!account) {
    errors.email = "An account with this email already exists. Please sign in.";
    return data({ errors, values: echo }, { status: 409 });
  }
  await appendMember(record); // lands in the shared members.xlsx
  if (token) {
    await sendMail(
      values.email,
      "Verify your school email | The Elevation Center",
      `Hello ${values.firstName},\n\nPlease confirm your school email to finish your free Student membership:\n${appOrigin(request)}/verify?token=${token}\n\nThe Elevation Center, University of New Haven`,
    );
  }
  return signIn(values.email, false, "/account?joined=1");
}

const STEP_FIELDS = {
  1: ["tier"],
  2: ["firstName", "lastName", "email", "type", "org", "password"],
  3: ["consent"],
};

function Err({ m }) {
  return m ? (
    <div className="msg" role="alert">
      {m}
    </div>
  ) : null;
}

function Legal({ url, children }) {
  return url ? (
    <a href={url} target="_blank" rel="noreferrer">
      {children}
    </a>
  ) : (
    <b>{children}</b>
  );
}

export default function Join({ actionData }) {
  const busy = useNavigation().state === "submitting";
  const formRef = useRef(null);
  const v = actionData?.values;
  const [errors, setErrors] = useState(actionData?.errors ?? {});
  const [step, setStep] = useState(1);
  const [tier, setTier] = useState(v?.tier ?? "");
  const [wantMentor, setWantMentor] = useState(v?.wantMentor ?? false);
  const [summary, setSummary] = useState([]);
  const stu = tier === "stu";
  useEffect(() => {
    if (!actionData?.errors) return;
    setErrors(actionData.errors);
    const keys = Object.keys(actionData.errors);
    if (keys.length) setStep(Math.min(...keys.map((k) => FIELD_STEP[k])));
  }, [actionData]);
  const read = () => parseJoin(new FormData(formRef.current));
  function review(vals) {
    const t = TIERS[vals.tier];
    const allowed = allowedOptions(vals.tier, vals.wantMentor);
    const opts = [...new Set(vals.options.filter((o) => allowed.includes(o)))];
    const rows = [
      [
        "Membership",
        `${t.label} (${t.price ? `$${t.price} for 12 months` : "Free"})`,
      ],
      ["Name", `${vals.firstName} ${vals.lastName}`],
      [stu ? "School email" : "Email", vals.email],
      [stu ? "School" : "Organization", vals.org],
    ];
    if (!stu) rows.push(["Member type", vals.type]);
    rows.push(["Options", opts.length ? opts.join(", ") : "None selected"]);
    rows.push(["Contact and introductions", "Agreed"]);
    if (!stu)
      rows.push([
        "Ambassador page",
        vals.listing ? "Yes, list me" : "No, do not list me",
      ]);
    setSummary(rows);
  }
  function next() {
    const vals = read();
    const all = validateJoin(vals);
    const here = {};
    for (const k of STEP_FIELDS[step] ?? []) if (all[k]) here[k] = all[k];
    setErrors(here);
    if (Object.keys(here).length) {
      const el = formRef.current?.querySelector(
        `.step:not([hidden]) .bad input, .step:not([hidden]) .bad select`,
      );
      el?.focus();
      return;
    }
    if (step === 3) review(vals);
    setStep(step + 1);
    window.scrollTo({ top: 0 });
  }
  function onSubmit(e) {
    if (step < 4) {
      e.preventDefault();
      next();
      return;
    }
    const all = validateJoin(read());
    const keys = Object.keys(all);
    if (keys.length) {
      e.preventDefault();
      setErrors(all);
      setStep(Math.min(...keys.map((k) => FIELD_STEP[k])));
    }
  }
  const bad = (k) => (errors[k] ? " bad" : "");
  const steps = ["Tier", "Details", "Options", "Confirm"];
  return (
    <AuthShell tabs wide>
      <Form method="post" ref={formRef} noValidate onSubmit={onSubmit}>
        <ol className="stepper">
          {steps.map((s, i) => (
            <li
              key={s}
              className={i + 1 < step ? "done" : i + 1 === step ? "on" : ""}
            >
              {s}
            </li>
          ))}
        </ol>

        <div className="step" hidden={step !== 1}>
          <h2 className="title">Choose your membership</h2>
          <p className="sub">
            Select the tier that fits you. Memberships run for 12 months from
            the date you join.
          </p>
          <div className="tiers" role="radiogroup" aria-label="Membership tier">
            {Object.keys(TIERS).map((k) => (
              <div key={k}>
                <input
                  type="radio"
                  name="tier"
                  id={`t-${k}`}
                  value={k}
                  defaultChecked={v?.tier === k}
                  onChange={() => {
                    setTier(k);
                    setErrors((e) => ({ ...e, tier: undefined }));
                  }}
                />
                <label htmlFor={`t-${k}`}>
                  <span className="n">{TIERS[k].label}</span>
                  <span className="pr">
                    {TIERS[k].price ? `$${TIERS[k].price}` : "Free"}
                  </span>
                  <span className="d">
                    {k === "stu"
                      ? "School email required"
                      : "12-month membership"}
                  </span>
                </label>
              </div>
            ))}
          </div>
          <Err m={errors.tier} />
        </div>

        <div className="step" hidden={step !== 2}>
          <h2 className="title">Your details</h2>
          <p className="sub">
            {stu
              ? "Students join free with a school email. We will send a link to verify it."
              : "Tell us a little about yourself."}
          </p>
          <div className="row">
            <div className={`f${bad("firstName")}`}>
              <label className="l" htmlFor="firstName">
                First name
              </label>
              <input
                id="firstName"
                name="firstName"
                autoComplete="given-name"
                defaultValue={v?.firstName}
              />
              <Err m={errors.firstName} />
            </div>
            <div className={`f${bad("lastName")}`}>
              <label className="l" htmlFor="lastName">
                Last name
              </label>
              <input
                id="lastName"
                name="lastName"
                autoComplete="family-name"
                defaultValue={v?.lastName}
              />
              <Err m={errors.lastName} />
            </div>
          </div>
          <div className={`f${bad("email")}`}>
            <label className="l" htmlFor="email">
              {stu ? "School email" : "Email address"}
            </label>
            <input
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              placeholder={stu ? "name@school.edu" : ""}
              defaultValue={v?.email}
            />
            <Err m={errors.email} />
          </div>
          <div className={`f${bad("type")}`} hidden={stu}>
            <label className="l" htmlFor="type">
              I am a
            </label>
            <select id="type" name="type" defaultValue={v?.type ?? ""}>
              <option value="">Select one</option>
              {MEMBER_TYPES.map((t) => (
                <option key={t}>{t}</option>
              ))}
            </select>
            <Err m={errors.type} />
          </div>
          <div className={`f${bad("org")}`}>
            <label className="l" htmlFor="org">
              {stu ? "School" : "Employer or organization"}
            </label>
            <input
              id="org"
              name="org"
              autoComplete="organization"
              defaultValue={v?.org}
            />
            <Err m={errors.org} />
          </div>
          <PasswordField
            id="password"
            name="password"
            label="Password"
            autoComplete="new-password"
            hint="At least 10 characters."
            error={errors.password}
          />
        </div>

        <div className="step" hidden={step !== 3}>
          <h2 className="title">Options</h2>
          <p className="sub">
            Check anything you would like. You can change these later.
          </p>
          <div hidden={stu}>
            <h3 className="sec">Mentors and speakers</h3>
            <div className="opts">
              {MENTOR_OPTIONS.map((o) => (
                <label className="chk" key={o}>
                  <input
                    type="checkbox"
                    name="options"
                    value={o}
                    defaultChecked={v?.options.includes(o)}
                  />
                  <span>{o}</span>
                </label>
              ))}
            </div>
            <label className="chk" style={{ marginTop: 8 }}>
              <input
                type="checkbox"
                name="wantMentor"
                checked={wantMentor}
                onChange={(e) => setWantMentor(e.target.checked)}
              />
              <span>I would also like a mentor</span>
            </label>
          </div>
          <div hidden={!(stu || wantMentor)}>
            <h3 className="sec">Students and anyone who wants a mentor</h3>
            <div className="opts">
              {MENTEE_OPTIONS.map((o) => (
                <label className="chk" key={o}>
                  <input
                    type="checkbox"
                    name="options"
                    value={o}
                    defaultChecked={v?.options.includes(o)}
                  />
                  <span>{o}</span>
                </label>
              ))}
            </div>
          </div>
          <h3 className="sec">Permissions</h3>
          <div className="opts">
            <label className="chk">
              <input
                type="checkbox"
                name="consent"
                defaultChecked={v?.consent}
                onChange={() =>
                  setErrors((e) => ({ ...e, consent: undefined }))
                }
              />
              <span>
                I agree to be contacted and introduced.
                <small>Required to complete your membership.</small>
              </span>
            </label>
            <label className="chk" hidden={stu}>
              <input
                type="checkbox"
                name="listing"
                defaultChecked={v?.listing}
              />
              <span>
                List me on the Ambassador page.
                <small>
                  Optional. Your name will appear on the Elevation Center
                  website.
                </small>
              </span>
            </label>
          </div>
          <Err m={errors.consent} />
        </div>

        <div className="step" hidden={step !== 4}>
          <h2 className="title">
            {stu ? "Review and confirm" : "Review and payment"}
          </h2>
          <p className="sub">Check your details before you finish.</p>
          {errors.email && step === 4 && (
            <div className="alert" role="alert">
              {errors.email}
            </div>
          )}
          <dl className="sum">
            {summary.map(([k, val]) => (
              <div key={k}>
                <dt>{k}</dt>
                <dd>{val}</dd>
              </div>
            ))}
          </dl>
          {stu ? (
            <div className="note">
              <b>Free membership.</b> No payment is needed. After you finish, we
              will email a link to verify your school email.
            </div>
          ) : (
            <div className="note">
              <b>Payment.</b> Online payment will open here once the University
              approves the payment path. Your registration is saved now, and we
              will email you instructions to pay your dues and activate your
              membership.
            </div>
          )}
          <p className="hint">
            By continuing you accept the{" "}
            <Legal url={TERMS_URL}>Terms of Use</Legal> and the{" "}
            <Legal url={PRIVACY_URL}>Online Privacy Statement</Legal>.
          </p>
        </div>

        <div className="nav">
          {step > 1 ? (
            <button
              type="button"
              className="btn s"
              onClick={() => {
                setStep(step - 1);
                window.scrollTo({ top: 0 });
              }}
            >
              Back
            </button>
          ) : (
            <span />
          )}
          {step < 4 ? (
            <button key="next" type="button" className="btn p" onClick={next}>
              Continue
            </button>
          ) : (
            <button
              key="submit"
              type="submit"
              className="btn p"
              disabled={busy}
            >
              {busy
                ? "Submitting..."
                : stu
                  ? "Complete registration"
                  : "Submit registration"}
            </button>
          )}
        </div>
        <p className="fine">
          Already a member? <Link to="/signin">Sign in</Link>
        </p>
      </Form>
    </AuthShell>
  );
}
